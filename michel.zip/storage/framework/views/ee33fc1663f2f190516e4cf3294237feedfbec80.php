<?php $__env->startSection('tituloPagina'); ?>
Produto > Cadastro
<?php $__env->stopSection(); ?>

<?php $__env->startSection('conteudoPrincipal'); ?>
    <div class="row">
        <div class="col-12 col-sm-12">
            <h4>Cadastro de produto</h4><hr>
        </div>
    </div>
    <div class="row">
        <div class="col-12 col-sm-12">
            <div class="card">
                <div class="card-body bg-light">
                    <form action="/produto/cadastro" method="post">
                        <?php echo e(csrf_field()); ?>

                        <div class="form-group">
                            <label for="nome"><h5>Nome do produto</h5></label>
                            <input type="text" id="nome" name="nome" class="form-control" maxlength="40">
                        </div>
                        <div class="form-group">
                            <label for="descricao"><h5>Descrição</h5></label>
                            <textarea id="descricao" name="descricao" class="form-control" maxlength="300"></textarea>
                        </div>
                        <div class="form-group">
                            <button type="submit" class="btn btn-success">Salvar</button>
                        </div>
                    </form>
                </div>
            </div>
            
        </div>
    </div>
    <div class="row">
        <div class="col-12 col-sm-12 text-right">
            <a href="/">< Voltar</a>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('modeloPage', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>