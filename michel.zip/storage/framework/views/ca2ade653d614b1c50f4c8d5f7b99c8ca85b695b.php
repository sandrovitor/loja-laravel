<?php $__env->startSection('tituloPagina'); ?>
Produto > Listar
<?php $__env->stopSection(); ?>

<?php $__env->startSection('conteudoPrincipal'); ?>
    <div class="row">
        <div class="col-12 col-sm-12">
            <h4>Lista de produtos</h4><hr>
        </div>
    </div>
    <div class="row">
        <div class="col-12 col-sm-12">
            <table class="table table-hover table-sm">
                <thead class="thead-dark">
                    <tr>
                        <th>ID</th>
                        <th>Nome</th>
                        <th>Descrição</th>
                        <th></th>
                    </tr>
                </thead>
                <tbody>
                    <?php echo $tabela; ?>

                </tbody>
            </table>
            
        </div>
    </div>
    <div class="row">
        <div class="col-12 col-sm-12 text-right">
            <a href="/">< Voltar</a>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('modeloPage', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>