<?php $__env->startSection('tituloPagina'); ?>
    Minha primeira loja Laravel
<?php $__env->stopSection(); ?>

<?php $__env->startSection('conteudoPrincipal'); ?>
    <div class="row">
        <div class="col-12 col-sm-12">
            <h4>Minha loja <small>(em laravel 5.5)</small></h4><hr>
        </div>
    </div>
    <div class="row">
        <div class="col-12 col-sm-12">
            <ul>
                <li><a href="produto/cadastro">Criar produto novo</a></li>
                <li><a href="produto/listar">Listar produtos</a></li>
                
            </ul>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('modeloPage', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>